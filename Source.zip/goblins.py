import pygame
import os
import main
import player
import other
import bat

GOBLIN_IDLE_IMAGE = pygame.image.load(os.path.join('Assets', 'goblins', 'goblin.png'))
GOBLIN_RUN_IMAGE = pygame.image.load(os.path.join('Assets', 'goblins', 'goblin run.png'))
GOBLIN_HURT_IMAGE = pygame.transform.scale(pygame.image.load(os.path.join('Assets', 'goblins', 'goblin defeat.png')),(45,45))
CROWN = pygame.transform.scale(pygame.image.load(os.path.join('Assets', 'goblins', 'goblin crown.png')),(45,45))
GOBLIN = pygame.transform.flip(
    pygame.transform.scale(GOBLIN_IDLE_IMAGE, (45,45)),True,False)

goblins_health = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
goblins_x =      [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
goblins_y =      [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
goblins_velx =   [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
goblins_vely =   [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]

goblin_score = [0]

def goblin_init():
    loop = 0
    while loop < len(goblins_health):
        goblins_health[loop] = 0
        goblins_x[loop] = 0
        goblins_y[loop] = 0
        goblins_velx[loop] = 0
        goblins_vely[loop] = 0
        goblin_score[0] = 0
        loop += 1

def goblin_stuff():
    loop = 0
    while loop < len(goblins_health):
        if goblins_health[loop] > 0:

            if other.anim[other.altframe]:
                if player.player[player.x] < goblins_x[loop]:
                    GOBLIN = pygame.transform.flip(
                        pygame.transform.scale(GOBLIN_IDLE_IMAGE, (45,45))
                            ,True,False)
                if player.player[player.x] > goblins_x[loop]:
                    GOBLIN = pygame.transform.flip(
                        pygame.transform.scale(GOBLIN_IDLE_IMAGE, (45,45))
                            ,False,False)
                if player.player[player.x] - goblins_x[loop] > -0.5 and player.player[player.x] - goblins_x[loop] < 0.5:
                    GOBLIN = pygame.transform.flip(
                        pygame.transform.scale(GOBLIN_IDLE_IMAGE, (45,45))
                            ,False,False)
                    goblins_velx[loop] = 0
            if not other.anim[other.altframe]:
                if player.player[player.x] < goblins_x[loop]:
                    GOBLIN = pygame.transform.flip(
                        pygame.transform.scale(GOBLIN_RUN_IMAGE, (45,45))
                            ,True,False)
                if player.player[player.x] > goblins_x[loop]:
                    GOBLIN = pygame.transform.flip(
                        pygame.transform.scale(GOBLIN_RUN_IMAGE, (45,45))
                            ,False,False)
                if player.player[player.x] - goblins_x[loop] > -0.5 and player.player[player.x] - goblins_x[loop] < 0.5:
                    GOBLIN = pygame.transform.flip(
                        pygame.transform.scale(GOBLIN_RUN_IMAGE, (45,45))
                            ,False,False)
                    goblins_velx[loop] = 0
        
            if player.player[player.x] > goblins_x[loop]:
                goblins_velx[loop] += 0.5
        
            if player.player[player.x] < goblins_x[loop]:
                goblins_velx[loop] -= 0.5
            
            if player.player[player.y] > goblins_y[loop]:
                goblins_vely[loop] += 0.5
        
            if player.player[player.y] < goblins_y[loop]:
                goblins_vely[loop] -= 0.5
        

            if goblins_velx[loop] != 0 and goblins_vely[loop] != 0:
                goblins_velx[loop] /= 1.141
                goblins_vely[loop] /= 1.141

            goblins_x[loop] += goblins_velx[loop]
            goblins_y[loop] += goblins_vely[loop]

            goblins_velx[loop] /= 1.25
            goblins_vely[loop] /= 1.25

            if other.collision(goblins_x[loop],goblins_y[loop],main.CHARSIZE,main.CHARSIZE
            ,player.player[player.x]-main.CHARSIZE,
                player.player[player.y]-main.CHARSIZE,main.CHARSIZE*3,main.CHARSIZE*3) and player.sword['slashing']:
                    goblins_velx[loop] = (goblins_x[loop] - player.player[player.x])/2
                    goblins_vely[loop] = (goblins_y[loop] - player.player[player.y])/2
                    goblins_health[loop] -= 1
                    main.score += 1
                    if goblins_health[loop] == 0:
                        goblins_health[loop] = -1
                        goblin_score[0] += 1
                        main.SCORE.play()
            
            oloop = 0
            while oloop < len(player.projectiles):
                if player.projectiles[oloop] != 0:
                    if other.collision(goblins_x[loop], goblins_y[loop], main.CHARSIZE, main.CHARSIZE, 
                        player.projectiles_x[oloop], player.projectiles_y[oloop], main.CHARSIZE, main.CHARSIZE):
                            goblins_velx[loop] = (goblins_x[loop] - player.projectiles_x[oloop])/2
                            goblins_velx[loop] = (goblins_y[loop] - player.projectiles_y[oloop])/2
                            if goblins_health[loop] > 1:
                                player.projectiles_x[oloop] = 1000
                                player.projectiles_y[oloop] = 1000
                            goblins_health[loop] -= 1
                            if goblins_health[loop] == 0:
                                goblins_health[loop] = -1    
                                goblin_score[0] += 1       
                                main.SCORE.play()
                oloop+=1

            main.WINDOW.blit(GOBLIN,(goblins_x[loop],goblins_y[loop]))
            if goblins_health[loop] > 1:
                main.WINDOW.blit(CROWN,(goblins_x[loop],goblins_y[loop]-15))
            
        if goblins_health[loop] < 0:
            goblins_health[loop] -= 1
            main.WINDOW.blit(GOBLIN_HURT_IMAGE,(goblins_x[loop],goblins_y[loop]))
            if goblins_health[loop] < -10:
                goblins_x[loop] = 0
                goblins_y[loop] = 0
                goblins_velx[loop] = 0
                goblins_vely[loop] = 0
                goblins_health[loop] = 0
        loop += 1
                                