import pygame
from pygame import key
import pygame.freetype
import os
from pygame.image import tostring
import player
import other
import goblins
import bat

pygame.init()
pygame.freetype.init()

#window settings
pygame.display.set_caption("Great Goblins")
WINDOW_LENGTH, WINDOW_HEIGHT = 900, 500
WINDOW = pygame.display.set_mode((WINDOW_LENGTH, WINDOW_HEIGHT))
ANOTHER_WINDOW = pygame.display.set_mode((WINDOW_LENGTH, WINDOW_HEIGHT))

pygame.display.set_icon(pygame.image.load(os.path.join('Assets', 'icon.png')))

pygame.mixer.music.load(os.path.join('Assets', 'Sounds', 'Mysterious Danger.wav'))
pygame.mixer.music.play(-1)

SWOOSH = pygame.mixer.Sound(os.path.join('Assets', 'Sounds', 'Swoosh.wav'))
SCORE = pygame.mixer.Sound(os.path.join('Assets', 'Sounds', 'point.wav'))
HIT = pygame.mixer.Sound(os.path.join('Assets', 'Sounds', 'Hit.wav'))
DEAD = pygame.mixer.Sound(os.path.join('Assets', 'Sounds', 'dead.wav'))

#font stuff
font = pygame.freetype.Font("Assets/Fonts/Roboto-Black.ttf", 30)
mediumfont = pygame.freetype.Font("Assets/Fonts/Roboto-Black.ttf", 20)
smallfont = pygame.freetype.Font("Assets/Fonts/Roboto-Black.ttf", 15)

#other important stuff
FPS = 60

score = 0

mode = 2

CHARSIZE = WINDOW_LENGTH/20

def sprite_def(dir,spritename,width,height):
    if dir == NotImplemented:
        return pygame.transform.scale(pygame.image.load(os.path.join('Assets', spritename)), (width,height))
    else:
        return pygame.transform.scale(pygame.image.load(os.path.join('Assets', dir, spritename)), (width,height))

BG = sprite_def('other', 'bg.png', 900, 500)

CIRCLE = sprite_def('other', 'circle.png', 135, 135)

def main():

    mode = 0

    game_running = True

    clock = pygame.time.Clock()

    while game_running:

        

        clock.tick(FPS)

        if mode != 1:
            WINDOW.fill((0,0,0))
        else:
            WINDOW.fill((50,50,50))

        if mode == 0:
            mediumfont.render_to(WINDOW,(0,0), 'Hi.', (255,255,255))
            mediumfont.render_to(WINDOW,(0,20), 'So.', (255,255,255))
            mediumfont.render_to(WINDOW,(0,40), 'Your goal is to defeat enemies while not dying.', (255,100,100))
            mediumfont.render_to(WINDOW,(0,60), 'You not die by not letting enemies touch you.', (255,255,255))
            mediumfont.render_to(WINDOW,(0,80), 'You can do this by running away from them with the arrow keys.', (100,100,255))
            mediumfont.render_to(WINDOW,(0,100), 'But what about defeating them?', (255,255,255))
            mediumfont.render_to(WINDOW,(0,120), 'You can do this by swinging your sword with X or', (100,100,255))
            mediumfont.render_to(WINDOW,(0,140), 'firing... whatever it is with Z.', (100,100,255))
            mediumfont.render_to(WINDOW,(0,160), 'But there is a catch! You have limited energy! You can see your', (100,255,100))
            mediumfont.render_to(WINDOW,(0,180), 'energy and health at the top of the screen.', (100,255,100))
            mediumfont.render_to(WINDOW,(0,220), 'Sorry about that massive wall of text.', (255,255,255))
            font.render_to(WINDOW,(230,450), 'Anyway, press Space to begin!', (255,255,100))

            WINDOW.blit(goblins.GOBLIN_IDLE_IMAGE,(630,100))
            WINDOW.blit(pygame.image.load(os.path.join('Assets', 'goblins', 'goblin crown.png')),(630,70))
            font.render_to(WINDOW,(590,220), 'Great Goblins', (255,255,255))
            smallfont.render_to(WINDOW,(520,250), "(The goblins in this game aren't actually great", (255,255,255))
            smallfont.render_to(WINDOW,(550,270), "I just like the alliteration in the title)", (255,255,255))

            pygame.display.update()

            keys_pressed = pygame.key.get_pressed()

            if keys_pressed[pygame.K_SPACE]:
                mode = 1

        if mode == 1:

            other.animation()

            goblins.goblin_stuff()

            bat.bat_stuff()

            player.player_stuff()

            other.enemy_spawning()

            font.render_to(WINDOW,(0,WINDOW_HEIGHT-30), 'Score: ' + str(goblins.goblin_score[0]+bat.goblin_score[0]), (255,255,255))

            pygame.display.update()

            if player.player[player.health] < 1:
                mode = 2
            

        if mode == 2:
            keys_pressed = pygame.key.get_pressed()
            font.render_to(WINDOW,(260,(WINDOW_HEIGHT/2)-15), 'You defeated ' + str(goblins.goblin_score[0]+bat.goblin_score[0]) + ' enemies', (255,255,255))
            font.render_to(WINDOW,(250,(WINDOW_HEIGHT/2)+30), 'Press the R key to try again', (255,255,255))
            other.anim[other.frame] -= 1
            pygame.display.update()
            mode = 1
            if keys_pressed[pygame.K_r]:
                player.player_init()
                goblins.goblin_init()
                bat.bat_init()
                other.other_init()
                mode = 1

        pygame.display.update()

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                game_running = False
    
    pygame.quit()

if __name__ == "__main__":
    main()