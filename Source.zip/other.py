import pygame
import os
import main
import player
import goblins
import bat
import random

#       0 1 2  3
anim = [0,0,15,False]
#the pointers to the array variables
frame = 0
altframetime = 1
altframetime_end = 2
altframe = 3

spawnstuff = {'spawnrate' : 200, 'spawnframe' : 0, 'enemy' : 0, 'location' : 0}

def other_init():
    anim[0] = 0
    anim[1] = 0
    anim[2] = 15
    anim[3] = False

    spawnstuff['spawnrate'] = 200
    spawnstuff['spawnframe'] = 0
    spawnstuff['enemy'] = 0
    spawnstuff['location'] = 0

def animation():
    anim[frame] += 1
    anim[altframetime] += 1
    if anim[altframetime] > anim[altframetime_end]:
        anim[altframetime]  = 0
        if anim[altframe] == False:
            anim[altframe] = True
        else:
            anim[altframe] = False

def enemy_spawning():
    spawnstuff['spawnframe'] += 1
    if spawnstuff['spawnframe'] > spawnstuff['spawnrate']:
        if spawnstuff['spawnrate'] > 60:
            spawnstuff['spawnrate'] -= 10
        spawnstuff['spawnframe'] = 0

        spawnstuff['enemy'] = random.randint(0,3)

        loop = 0
        if spawnstuff['enemy'] == 0 or spawnstuff['enemy'] == 1:
            while loop < len(goblins.goblins_health):
                if goblins.goblins_health[loop] == 0:

                    goblins.goblins_health[loop] = 1
                    
                    spawnstuff['location'] = random.randint(0,3)
                    if spawnstuff['location'] == 0:
                        goblins.goblins_x[loop] = random.randint(0,main.WINDOW_LENGTH)
                    if spawnstuff['location'] == 1:
                        goblins.goblins_y[loop] = random.randint(0,main.WINDOW_HEIGHT)
                    if spawnstuff['location'] == 2:
                        goblins.goblins_x[loop] = random.randint(0,main.WINDOW_LENGTH)
                        goblins.goblins_y[loop] = main.WINDOW_HEIGHT
                    if spawnstuff['location'] == 3:
                        goblins.goblins_y[loop] = random.randint(0,main.WINDOW_HEIGHT)
                        goblins.goblins_x[loop] = main.WINDOW_LENGTH
                    break
                loop+=1
        if spawnstuff['enemy'] == 2:
            while loop < len(bat.goblins_health):
                if bat.goblins_health[loop] == 0:

                    bat.goblins_health[loop] = 1
                    
                    spawnstuff['location'] = random.randint(0,3)
                    if spawnstuff['location'] == 0:
                        bat.goblins_x[loop] = random.randint(0,main.WINDOW_LENGTH)
                    if spawnstuff['location'] == 1:
                        bat.goblins_y[loop] = random.randint(0,main.WINDOW_HEIGHT)
                    if spawnstuff['location'] == 2:
                        bat.goblins_x[loop] = random.randint(0,main.WINDOW_LENGTH)
                        bat.goblins_y[loop] = main.WINDOW_HEIGHT
                    if spawnstuff['location'] == 3:
                        bat.goblins_y[loop] = random.randint(0,main.WINDOW_HEIGHT)
                        bat.goblins_x[loop] = main.WINDOW_LENGTH
                    break
                loop+=1
        if spawnstuff['enemy'] == 3:
            while loop < len(goblins.goblins_health):
                if goblins.goblins_health[loop] == 0:

                    goblins.goblins_health[loop] = 2
                    
                    spawnstuff['location'] = random.randint(0,3)
                    if spawnstuff['location'] == 0:
                        goblins.goblins_x[loop] = random.randint(0,main.WINDOW_LENGTH)
                    if spawnstuff['location'] == 1:
                        goblins.goblins_y[loop] = random.randint(0,main.WINDOW_HEIGHT)
                    if spawnstuff['location'] == 2:
                        goblins.goblins_x[loop] = random.randint(0,main.WINDOW_LENGTH)
                        goblins.goblins_y[loop] = main.WINDOW_HEIGHT
                    if spawnstuff['location'] == 3:
                        goblins.goblins_y[loop] = random.randint(0,main.WINDOW_HEIGHT)
                        goblins.goblins_x[loop] = main.WINDOW_LENGTH
                    break
                loop+=1

def collision(x,y,w,h,x2,y2,w2,h2):
    if x > x2 and x < x2 + w2:
        if y > y2 and y < y2 + h2:
            return True
    if x+w > x2 and x+w < x2 + w2:
        if y > y2 and y < y2 + h2:
            return True
    if x > x2 and x < x2 + w2:
        if y+h > y2 and y+h < y2 + h2:
            return True
    if x+w > x2 and x+w < x2 + w2:
        if y+h > y2 and y+h < y2 + h2:
            return True
    
    return False