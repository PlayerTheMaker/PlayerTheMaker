import pygame
import os
from pygame.constants import BLEND_RGB_ADD
import main
import other
import goblins
import bat

WINDOW_LENGTH, WINDOW_HEIGHT = 900, 500

#sprites
PLAYER_IDLE_IMAGE = pygame.image.load(os.path.join('Assets', 'Player', 'Player.png'))
PLAYER_IDLE = pygame.transform.scale(PLAYER_IDLE_IMAGE, (WINDOW_LENGTH/20,WINDOW_LENGTH/20))
PLAYER_IDLE_FLIPPED = pygame.transform.flip(
    pygame.transform.scale(PLAYER_IDLE_IMAGE, (WINDOW_LENGTH/20,WINDOW_LENGTH/20)),True,False)

PLAYER_RUN_IMAGE = pygame.image.load(os.path.join('Assets', 'Player', 'Player Run.png'))
PLAYER_RUN = pygame.transform.scale(PLAYER_RUN_IMAGE, (WINDOW_LENGTH/20,WINDOW_LENGTH/20))
PLAYER_RUN_FLIPPED = pygame.transform.flip(
    pygame.transform.scale(PLAYER_RUN_IMAGE, (WINDOW_LENGTH/20,WINDOW_LENGTH/20)),True,False)

PLAYER_HURT_IMAGE = pygame.image.load(os.path.join('Assets', 'Player', 'Player Hurt.png'))
PLAYER_HURT = pygame.transform.scale(PLAYER_HURT_IMAGE, (WINDOW_LENGTH/20,WINDOW_LENGTH/20))

PLAYER_ACTION_IMAGE = pygame.image.load(os.path.join('Assets', 'Player', 'Player Action.png'))
PLAYER_ACTION = pygame.transform.scale(PLAYER_ACTION_IMAGE, (WINDOW_LENGTH/20,WINDOW_LENGTH/20))

FIREBALL = main.sprite_def('Attacks','Projectile (1).png',main.CHARSIZE,main.CHARSIZE)

HEART = main.sprite_def('Other','Health.png',25,25)
BOLT = main.sprite_def('Other','Energy.png',25,25)

#player variables and I did not know how to use dictionaries in pythin properly, so...
#         0   1   2 3 4  5   6 7    8           9     10    11    12 13
player = [100,200,0,0,10,1.5,5,1.25,PLAYER_IDLE,False,False,False,1, 0]
#these are pointers to the variables, the actual vars are above
x = 0
y = 1
velx = 2
vely = 3
health = 4
accel = 5
maxvel = 6
friction = 7
sprite = 8
flipped = 9
moving = 10
hurt = 11
power = 12
dir = 13

swordsprites = {
'1' : main.sprite_def('Attacks', 'Sword (0).png', (WINDOW_LENGTH/20)*3, (WINDOW_LENGTH/20)*3),
'2' : main.sprite_def('Attacks', 'Sword (1).png', (WINDOW_LENGTH/20)*3, (WINDOW_LENGTH/20)*3),
'3' : main.sprite_def('Attacks', 'Sword (2).png', (WINDOW_LENGTH/20)*3, (WINDOW_LENGTH/20)*3),
'4' : main.sprite_def('Attacks', 'Sword (4).png', (WINDOW_LENGTH/20)*3, (WINDOW_LENGTH/20)*3),
'5' : main.sprite_def('Attacks', 'Sword (3).png', (WINDOW_LENGTH/20)*3, (WINDOW_LENGTH/20)*3),
'6' : main.sprite_def('Attacks', 'Sword (5).png', (WINDOW_LENGTH/20)*3, (WINDOW_LENGTH/20)*3)
}

sword = {'slashing': False, 'swordframe': 1000, 'swordsprite': 1}

projectiles =   [0,0,0,0,0,0,0,0,0]
projectiles_x = [0,0,0,0,0,0,0,0,0]
projectiles_y = [0,0,0,0,0,0,0,0,0]
projectile_can_do = [0]

def player_init():
    player[0] = 100
    player[1] = 200
    player[2] = 0
    player[3] = 0
    player[4] = 10
    player[5] = 1.5
    player[6] = 5
    player[7] = 1.25
    player[8] = PLAYER_IDLE
    player[9] = False
    player[10] = False
    player[11] = False
    player[12] = 1
    player[13] = 0

    sword['slashing'] == False
    sword['swordframe'] == 1000
    sword['swordsprite'] == 1

    loop = 0

    while loop < len(projectiles):
        projectiles[loop] = 0
        projectiles_x[loop] = 0
        projectiles_y[loop] = 0
        loop += 1
    projectile_can_do[0] = 0


ARROW = main.sprite_def('Arrows', 'ArrowRight.png', WINDOW_LENGTH/20, WINDOW_LENGTH/20)

def player_stuff():

    main.WINDOW.blit(main.CIRCLE,(player[x]-main.CHARSIZE, player[y]-main.CHARSIZE))

    projectile_can_do[0] += 0.1

    player[power] += 0.183

    if player[power] > 100:
        player[power] = 100

    keys_pressed = pygame.key.get_pressed()
    
    if player[health] > 0:
        if keys_pressed[pygame.K_x] and player[power] > 33 and projectile_can_do[0] >= 1:
            loop = 0
            player[power] -= 33
            while loop < len(projectiles):
                if projectiles[loop] == 0:
                    projectiles[loop] = player[dir]+1
                    projectiles_x[loop] = player[x]
                    projectiles_y[loop] = player[y]
                    projectile_can_do[0] = 0
                    main.SWOOSH.play()
                    break
                loop += 1


        if keys_pressed[pygame.K_RIGHT]:
            player[velx] += player[accel]
            player[dir] = 0
        if keys_pressed[pygame.K_LEFT]:
            player[velx] -= player[accel]
            player[dir] = 2
        if keys_pressed[pygame.K_DOWN]:
            player[vely] += player[accel]
            player[dir] = 1
        if keys_pressed[pygame.K_UP]:
            player[vely] -= player[accel]
            player[dir] = 3
        
        

        if keys_pressed[pygame.K_z] and player[power] > 33 and not sword['slashing']:
            sword['slashing'] = True
            sword['swordframe'] = 0
            sword['swordsprite'] = 1
            player[power] -= 33
            main.SWOOSH.play()
    
    if player[dir] == 0:
        ARROW = main.sprite_def('Arrows', 'ArrowRight.png', main.CHARSIZE*2, main.CHARSIZE*2)
    if player[dir] == 1:
        ARROW = main.sprite_def('Arrows', 'ArrowDown.png', main.CHARSIZE*2, main.CHARSIZE*2)
    if player[dir] == 2:
        ARROW = main.sprite_def('Arrows', 'ArrowLeft.png', main.CHARSIZE*2, main.CHARSIZE*2)
    if player[dir] == 3:
        ARROW = main.sprite_def('Arrows', 'ArrowUp.png', main.CHARSIZE*2, main.CHARSIZE*2)

    sword['swordframe'] += 1

    if sword['swordframe']%4 == 0 and sword['swordsprite'] < 6:
        sword['swordsprite'] += 1

    if player[velx] > player[maxvel]:
        player[velx] = player[maxvel]

    if player[velx] < -player[maxvel]:
        player[velx] = -player[maxvel]

    if player[vely] > player[maxvel]:
        player[vely] = player[maxvel]

    if player[vely] < -player[maxvel]:
        player[vely] = -player[maxvel]

    if player[velx] != 0 and player[vely] != 0:
        player[velx] /= 1.141
        player[vely] /= 1.141

    
    #enemy collision

    loop = 0
    while loop < len(goblins.goblins_health):
        if other.collision(goblins.goblins_x[loop],goblins.goblins_y[loop],45,45,
                    player[x],player[y],45,45) and goblins.goblins_health[loop] != 0:
                        player[velx] = -(goblins.goblins_x[loop] - player[x])*1.5
                        player[vely] = -(goblins.goblins_y[loop] - player[y])*1.5
                        player[health] -= 1
                        player[hurt] = True
                        main.HIT.play()
        loop += 1
    
    loop = 0
    while loop < len(bat.goblins_health):
        if other.collision(bat.goblins_x[loop],bat.goblins_y[loop],45,45,
                    player[x],player[y],45,45) and bat.goblins_health[loop] != 0:
                        player[velx] = -(bat.goblins_x[loop] - player[x])*1.5
                        player[vely] = -(bat.goblins_y[loop] - player[y])*1.5
                        player[health] -= 1
                        player[hurt] = True
                        main.HIT.play()
        loop += 1

    player[x] += player[velx]
    player[y] += player[vely]

    if player[x] < 0:
        player[x] = 0
    if player[y] < 0:
        player[y] = 0
    if player[x] > main.WINDOW_LENGTH-main.CHARSIZE:
        player[x] = main.WINDOW_LENGTH-main.CHARSIZE
    if player[y] > main.WINDOW_HEIGHT-main.CHARSIZE:
        player[y] = main.WINDOW_HEIGHT-main.CHARSIZE

    player[velx] /= player[friction]
    player[vely] /= player[friction]

    if player[velx] < 0.5 and player[velx] > -0.5:
        player[velx] = 0

    if player[vely] < 0.5 and player[vely] > -0.5:
        player[vely] = 0

    if player[velx] != 0 or player[vely] != 0:
        player[moving] = True
    else:
        player[moving] = False

    if player[velx] > 0:
        player[flipped] = False
    if player[velx] < 0:
        player[flipped] = True

    if other.anim[other.altframe]:
        PLAYER_RUN = pygame.transform.flip(
        pygame.transform.scale(PLAYER_RUN_IMAGE, (WINDOW_LENGTH/20,WINDOW_LENGTH/20)),player[flipped],False)
    else:
        PLAYER_RUN = pygame.transform.flip(
        pygame.transform.scale(PLAYER_IDLE_IMAGE, (WINDOW_LENGTH/20,WINDOW_LENGTH/20)),player[flipped],False)

    PLAYER_IDLE = pygame.transform.flip(
    pygame.transform.scale(PLAYER_IDLE_IMAGE, (WINDOW_LENGTH/20,WINDOW_LENGTH/20)),player[flipped],False)

    if player[moving] == True:
        player[sprite] = PLAYER_RUN
    else:
        player[sprite] = PLAYER_IDLE
    
    if player[hurt] == True:
        PLAYER_ACTION = pygame.transform.flip(
            pygame.transform.scale(PLAYER_ACTION_IMAGE, (WINDOW_LENGTH/20,WINDOW_LENGTH/20)),player[flipped],False)
        player[sprite] = PLAYER_ACTION

        if other.anim[other.altframe]:
            player[hurt] = 10
        
        player[velx] /= 2
        player[vely] /= 2
    
    if player[hurt] != False and player[hurt] != True:
        PLAYER_ACTION = pygame.transform.flip(
            pygame.transform.scale(PLAYER_ACTION_IMAGE, (WINDOW_LENGTH/20,WINDOW_LENGTH/20)),player[flipped],False)
        player[sprite] = PLAYER_ACTION
        player[velx] /= 2
        player[vely] /= 2
        if not other.anim[other.altframe]:
            player[hurt] = False

    #the draw stuff
    main.WINDOW.blit(player[sprite],(player[x],player[y]))

    main.WINDOW.blit(ARROW,(player[x]-main.CHARSIZE/2,player[y]-main.CHARSIZE/2))

    loop = 0
    while loop < len(projectiles):
        if projectiles[loop] != 0:

            if projectiles[loop] == 1:
                projectiles_x[loop] += 10
            if projectiles[loop] == 2:
                projectiles_y[loop] += 10
            if projectiles[loop] == 3:
                projectiles_x[loop] -= 10
            if projectiles[loop] == 4:
                projectiles_y[loop] -= 10
            
            if other.anim[other.altframe]:
                FIREBALL = main.sprite_def('Attacks','Projectile (2).png',main.CHARSIZE,main.CHARSIZE)
            else:
                FIREBALL = main.sprite_def('Attacks','Projectile (1).png',main.CHARSIZE,main.CHARSIZE)

            if projectiles_x[loop] > main.WINDOW_LENGTH or projectiles_x[loop] < 0-main.CHARSIZE or projectiles_y[loop] > main.WINDOW_HEIGHT or projectiles_x[loop] < 0 - main.CHARSIZE:
                projectiles[loop] = 0

            main.WINDOW.blit(FIREBALL,(projectiles_x[loop],projectiles_y[loop]))
        loop += 1

    if sword['swordframe'] > (4*6)-3:
        sword['slashing'] = False

    if sword['slashing']:
        main.WINDOW.blit(swordsprites[str(sword['swordsprite'])],(player[x]-main.CHARSIZE,player[y]-main.CHARSIZE))

    pygame.draw.rect(main.WINDOW,(30,200,30),(0,0,player[power]*9,20))
    pygame.draw.rect(main.WINDOW,(200,30,30),(0,20,player[health]*90,20))
    main.WINDOW.blit(BOLT,(main.WINDOW_LENGTH-25, 1-other.anim[other.altframe]))
    main.WINDOW.blit(HEART,(main.WINDOW_LENGTH-25, 22+other.anim[other.altframe]))
    pygame.draw.rect(main.WINDOW,(255,255,255),(295,0,10,20))
    pygame.draw.rect(main.WINDOW,(255,255,255),(595,0,10,20))
    
    #damage stuff
    if player[hurt] != False:
        PLAYER_HURT = pygame.transform.flip(
            pygame.transform.scale(PLAYER_HURT_IMAGE, (WINDOW_LENGTH/20,WINDOW_LENGTH/20)),player[flipped],False)
        main.WINDOW.blit(PLAYER_HURT, (player[x],player[y]), special_flags=BLEND_RGB_ADD)
        main.WINDOW.blit(PLAYER_HURT, (player[x],player[y]), special_flags=BLEND_RGB_ADD)
    
    